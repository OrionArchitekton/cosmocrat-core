// Optional: If you later move scoring out of the LLM into code, implement it here.
export function scoreScenario() {
  // placeholder
  return null;
}
